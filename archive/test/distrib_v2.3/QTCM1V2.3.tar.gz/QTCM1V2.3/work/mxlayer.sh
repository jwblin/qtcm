#!/bin/csh
# A QTCM run with a ocean mixed layer
#
# ============================================================

# Set Macro switches for compilation (see makefile)
# -------------------------------------------------
#
# always use 360day per year calendar because of the SST tendency calculation  
# in Step 2 : aveflux.f
 
set DEFS = "-DYEAR360"

# String to document the macros in effect
set defs_str = `echo "$DEFS" | sed -e 's/ -D/_/g' `

# adjust RUNNAME 
set RUNNAME = `basename $0 .sh`

# Set directories 
# ---------------
#
set SCRIPTDIR = `pwd`                    # directory of the script
set QTCMROOT  = $SCRIPTDIR/..            # root directory
set INIDIR    = $QTCMROOT/inidata        # directory of restart file
set SRCDIR    = $QTCMROOT/src            # Set the source directory 
set BNDDIR    = $QTCMROOT/bnddata/r64x42 # Boundary data directory
set OUTDIR    = $QTCMROOT/proc/${RUNNAME}${defs_str}  # Output dirctory
set LOGFILE = ${RUNNAME}.log             # model output log file
set SCRIPT  = `basename $0`              # script name 

# Let the user know the settings:
#
echo Script Settings:
echo Output directory: $OUTDIR
echo RUNNAME : "$RUNNAME"
echo Preprocessor macro definitions: $DEFS
echo -----------------------
echo ' '

#if ( "$DEFS" == "blabla" )  then

echo Step 1
# =======================================
# Step 1 (control run): 
# run qtcm_seasonal run to generate Qflux (net sfc. flux + Ts tendency)
# =======================================

# Compile qtcm in source dir
# --------------------------
#
cd $SRCDIR
# remove old object files if preprocessor flags are set 
if ( "$DEFS" != '' )  make clean 
make DEFS="${DEFS}" qtcm || exit


if ( ! -d $OUTDIR )  mkdir $OUTDIR

# Store script and source code in an archive in the output dir
#
tar -uf $OUTDIR/${RUNNAME}_src.tar *.f90 makefile
cd $SCRIPTDIR
tar -uf $OUTDIR/${RUNNAME}_src.tar $SCRIPT
gzip -f $OUTDIR/${RUNNAME}_src.tar

cd $OUTDIR

# Get restart file and executable
# ----------------------------------------------
# 
cp $INIDIR/qtcm.restart .
cp -fp $SRCDIR/qtcm .


# Copy the script into the output log file
# ----------------------------------------
#
cp $SCRIPTDIR/$SCRIPT $LOGFILE
chmod -x $OUTDIR/$LOGFILE


# Generate user input file
# ------------------------
#
sed 's/\!.*$//' > driver.in << EOF
 &driverdata
 title='A QTCM run with prescribed SST (seasonal)'
 bnddir='$BNDDIR' 
 SSTdir='$BNDDIR/SST_Reynolds'
 outdir='$OUTDIR'
 runname='${RUNNAME}_control'
 SSTmode='seasonal'                  ! decide what kind of SST to use
 year0 = -1                    ! starting year if <0 use year in restart file
 month0 = 11          ! starting month if <0 use month in restart file
 day0 = 1             ! -1 and mrestart=1: Use date saved in the restart file
 lastday = 3660  ! 10 years (3600 days) + noout (60 days)
! lastday= 1140  ! 3x360 days +60 for start at 01 Nov
 noout= 60      ! discrad first 2 month
 !
 ! default values for input:
 !  title='QTCM default title'          ! A decrciptive title 
 !  bnddir='../bnddata'                 ! bnd. data other than SST
 !  SSTdir='../bnddata/SST_Reynolds' ! where SST files are
 !  outdir='../proc/qtcm_output'        ! where output go
 !  runname='runname'                   ! string used to create an output filename
 !  landon=1                            ! if not 1: land is like ocean with fake 'SST'
 !  year0 = -1                          ! starting year if <0 use year in restart file
 !  month0 = -1                         ! starting month if <0 use month in restart file
 !  day0 = -1                           ! -1 and mrestart=1: Use date saved in the restart file
 !  lastday = daysperyear               ! last day of integration
 !  interval = 1                        ! coupling interval
 !  noout=0                             ! no output for the first noout days
 !  ntout=-30                           ! monthly mean output
 !  ntouti=0                            ! monthly instantaneous data output
 !  ntoutr=-30                          ! monthly restart file
 !  mrestart=1                          ! =1: restart using qtcm.restart
 !  dt=1200.                            ! time step [seconds]
 !  mt0=1                               ! barotropic timestep every mt0 timesteps
 !  viscT=12.0e5                        ! temperature diffusion parameter [m^s/s]
 !  viscQ=12.0e5                        ! humidity diffusion parameter [m^s/s]
 !  viscU=7.0e5                         ! viscocity parameter [m^s/s]
 !  ziml=400                            ! Atmos. Mixed layer depth [m]
 !  weml=0.02                           ! Mixed layer entrainment velocity [m]
 !  Wsmin=4.5                          ! Minumum wind speed for flux calculation [m/s]
 !  V1b=-0.2204077                      ! V1 projection coeffcicient at top of mixed layer
 !  arr1name='?'                        ! Auxiliary output array names 1...8
 !  arr2name='?'                        !='?' Array not included in output.
 !  arr3name='?'
 !  arr4name='?'
 !  arr5name='?'
 !  arr6name='?'
 !  arr7name='?'
 !  arr8name='?'
 ! Example:
 ! arr1name='dps1dx Mode 1 contribution to dpsdx [m/s^2]'
 !----------------------------------------------------------------
 &end
EOF
# Run qtcm using nice
# -------------------
# Timing the run. Output to screen and logfile
#
/usr/bin/time nice qtcm |& tee -a ${LOGFILE}_control

/bin/rm qtcm

echo Step 2
# ===========================================================
# Step 2 
# use the output generated from control run (Step1) to get 
#   annual mean and seasonal averaged Fsnet and temp tendency
# ===========================================================
#
cd $SRCDIR
make aveflux
cp aveflux $OUTDIR
cd OUTDIR 
echo ${RUNNAME}_control
ln -s qm_${RUNNAME}_control.out qm.out
 aveflux
 echo 'Step 2 finished'

#endif

echo Step 3
# ===================================================
# Step 3 
# Run qtcm using the mixed-layer ocean model
# Note: users must uncomment 'call cplmean' in qtcm.f 
# ===================================================

#- Compile qtcm using make in srcdir, but run it in workdir
cd $SRCDIR
/bin/rm ocean.o qtcm 
if ( "$DEFS" != '' )  make clean
make DEFS="${DEFS} -DMXL_OCEAN" qtcm || exit
# remove ocean.o and qtcm from the source dir

cd $OUTDIR
cp -fp $SRCDIR/qtcm .
/bin/rm $SRCDIR/ocean.o $SRCDIR/qtcm 

mv driver.in driver.in_control

sed 's/\!.*$//' > driver.in << EOF
 &driverdata
 title='A QTCM mixed layer run'
 bnddir='$BNDDIR' 
 SSTdir='$BNDDIR/SST_Reynolds'
 outdir='$OUTDIR'
 runname='$RUNNAME'
 SSTmode='seasonal'           ! decide what kind of QFLUX to use
 year0=-1
 lastday = 3660   ! 10x360 days +60 for start at 01 Nov
 noout= 60      ! discard first 2 month
 month0=11
 day0=1
 viscT=12.0e5                        ! temperature diffusion parameter [m^s/s]
 viscQ=12.0e5                        ! humidity diffusion parameter [m^s/s]
 ViscU=7.0e5                         ! viscocity parameter [m^s/s]
 &end
EOF

# Run qtcm using nice
# -------------------
# Timing the run. Output to screen and logfile
#
/usr/bin/time nice qtcm |& tee -a $LOGFILE
#
# ---------- end of c-shell script -------------- 
